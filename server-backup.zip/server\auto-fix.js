// Auto-fix common issues
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

console.log('🔧 Auto-Fixing Common Issues...\n');

const fixes = [];

// Fix 1: Create .env if missing
const envPath = path.join(__dirname, '.env');
if (!fs.existsSync(envPath)) {
  console.log('✅ Creating .env file...');
  const defaultEnv = `MONGODB_URI=mongodb://localhost:27017/gym_management
PORT=5000
JWT_SECRET=your_secret_key_change_in_production_${Date.now()}
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password
`;
  fs.writeFileSync(envPath, defaultEnv);
  fixes.push('Created .env file');
}

// Fix 2: Check if MongoDB service exists (Windows)
if (process.platform === 'win32') {
  console.log('✅ Checking MongoDB service (Windows)...');
  exec('sc query MongoDB', (error, stdout) => {
    if (error) {
      console.log('⚠️  MongoDB service not found. Install MongoDB first.');
    } else if (stdout.includes('STOPPED')) {
      console.log('✅ MongoDB service found but stopped.');
      console.log('   Run: net start MongoDB');
      fixes.push('MongoDB service needs to be started');
    } else if (stdout.includes('RUNNING')) {
      console.log('✅ MongoDB service is running!');
    }
  });
}

// Fix 3: Check if port 5000 is available
const net = require('net');
const server = net.createServer();
server.listen(5000, () => {
  server.close(() => {
    console.log('✅ Port 5000 is available');
  });
});
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log('⚠️  Port 5000 is already in use');
    console.log('   Solution: Kill the process or change PORT in .env');
    fixes.push('Port 5000 is in use');
  }
});

console.log('\n✅ Auto-fix complete!');
if (fixes.length > 0) {
  console.log('\n📝 Issues found:');
  fixes.forEach(fix => console.log('   - ' + fix));
} else {
  console.log('✅ No issues found!');
}

console.log('\n📝 Next: Run "npm run check" to verify setup');



