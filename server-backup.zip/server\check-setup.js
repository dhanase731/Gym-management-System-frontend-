// Setup checker script
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

console.log('🔍 Checking Gym Management System Setup...\n');

let issues = [];
let warnings = [];

// Check 1: .env file
const envPath = path.join(__dirname, '.env');
if (!fs.existsSync(envPath)) {
  warnings.push('⚠️  .env file not found. Creating default .env file...');
  const defaultEnv = `MONGODB_URI=mongodb://localhost:27017/gym_management
PORT=5000
JWT_SECRET=your_secret_key_change_in_production_${Date.now()}
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password
`;
  fs.writeFileSync(envPath, defaultEnv);
  console.log('✅ Created .env file with default values');
} else {
  console.log('✅ .env file exists');
}

// Check 2: MongoDB Connection
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/gym_management';

console.log('\n📡 Testing MongoDB connection...');
console.log('   Connection string:', MONGODB_URI.replace(/\/\/.*@/, '//***@'));

mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  serverSelectionTimeoutMS: 5000,
})
.then(async () => {
  console.log('✅ MongoDB Connected Successfully!');
  console.log('   Database:', mongoose.connection.name);
  
  // Test a simple operation
  try {
    await mongoose.connection.db.admin().ping();
    console.log('✅ MongoDB is responding');
  } catch (err) {
    warnings.push('⚠️  MongoDB connected but not responding to ping');
  }
  
  await mongoose.connection.close();
  
  console.log('\n✅ All checks passed!');
  console.log('\n📝 Next steps:');
  console.log('   1. Run: npm start');
  console.log('   2. Open: http://localhost:5000/api/health');
  console.log('   3. Start frontend: cd .. && npm start');
  
  if (warnings.length > 0) {
    console.log('\n⚠️  Warnings:');
    warnings.forEach(w => console.log('   ' + w));
  }
  
  process.exit(0);
})
.catch(err => {
  issues.push('MongoDB Connection Failed');
  console.error('❌ MongoDB Connection Error:', err.message);
  
  console.log('\n🔧 Solutions:');
  console.log('\n1. For Local MongoDB:');
  console.log('   Windows:');
  console.log('     - Open Services (services.msc)');
  console.log('     - Find "MongoDB" service');
  console.log('     - Right-click → Start');
  console.log('   Mac/Linux:');
  console.log('     - Run: mongod');
  console.log('     - Or: brew services start mongodb-community');
  
  console.log('\n2. For MongoDB Atlas (Cloud):');
  console.log('   - Go to: https://www.mongodb.com/cloud/atlas');
  console.log('   - Create free cluster');
  console.log('   - Get connection string');
  console.log('   - Update MONGODB_URI in .env file');
  console.log('   - Whitelist your IP address');
  
  console.log('\n3. Test connection manually:');
  console.log('   - Run: node test-connection.js');
  
  console.log('\n❌ Setup incomplete. Please fix MongoDB connection.');
  process.exit(1);
});



