const mongoose = require('mongoose');

const billingSchema = new mongoose.Schema({
  memberId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Member',
    required: true
  },
  memberName: {
    type: String,
    required: true
  },
  gymId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Gym'
  },
  gymName: {
    type: String
  },
  plan: {
    type: String,
    required: true,
    enum: ['Basic', 'Standard', 'Premium']
  },
  amount: {
    type: Number,
    required: true
  },
  dueDate: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    default: 'Pending',
    enum: ['Paid', 'Pending', 'Overdue']
  },
  paymentMethod: {
    type: String,
    enum: ['Credit Card', 'UPI', 'Cash', 'Bank Transfer']
  },
  invoiceNumber: {
    type: String,
    unique: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  paidAt: {
    type: Date
  }
});

// Generate invoice number before saving
billingSchema.pre('save', async function(next) {
  if (!this.invoiceNumber) {
    const count = await mongoose.model('Billing').countDocuments();
    this.invoiceNumber = `INV-${Date.now()}-${count + 1}`;
  }
  next();
});

module.exports = mongoose.model('Billing', billingSchema);

