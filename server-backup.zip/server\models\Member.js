const mongoose = require('mongoose');

const memberSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    trim: true
  },
  phone: {
    type: String,
    required: true,
    trim: true
  },
  plan: {
    type: String,
    required: true,
    enum: ['Basic', 'Standard', 'Premium']
  },
  status: {
    type: String,
    default: 'Active',
    enum: ['Active', 'Inactive']
  },
  joinDate: {
    type: Date,
    default: Date.now
  },
  gymId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Gym'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Member', memberSchema);

