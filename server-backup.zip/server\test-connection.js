// Quick test script to check if everything is working
const mongoose = require('mongoose');
require('dotenv').config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/gym_management';

console.log('Testing MongoDB connection...');
console.log('Connection string:', MONGODB_URI.replace(/\/\/.*@/, '//***@')); // Hide credentials

mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('✅ MongoDB Connected Successfully!');
  console.log('✅ Database:', mongoose.connection.name);
  console.log('✅ Ready to accept connections');
  process.exit(0);
})
.catch(err => {
  console.error('❌ MongoDB Connection Error:', err.message);
  console.error('\nTroubleshooting:');
  console.error('1. Make sure MongoDB is running');
  console.error('2. Check your connection string in .env file');
  console.error('3. For local MongoDB: mongodb://localhost:27017/gym_management');
  console.error('4. For Atlas: Use your Atlas connection string');
  process.exit(1);
});

