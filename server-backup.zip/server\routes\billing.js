const express = require('express');
const router = express.Router();
const Billing = require('../models/Billing');
const Member = require('../models/Member');
const Gym = require('../models/Gym');
const nodemailer = require('nodemailer');

// Email transporter setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Get all billing records
router.get('/', async (req, res) => {
  try {
    const bills = await Billing.find()
      .populate('memberId', 'name email phone')
      .populate('gymId', 'gymName')
      .sort({ createdAt: -1 });
    res.json(bills);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get single billing record
router.get('/:id', async (req, res) => {
  try {
    const bill = await Billing.findById(req.params.id)
      .populate('memberId')
      .populate('gymId');
    if (!bill) {
      return res.status(404).json({ message: 'Billing record not found' });
    }
    res.json(bill);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Create billing record
router.post('/', async (req, res) => {
  try {
    const { memberId, memberName, gymId, gymName, plan, amount, dueDate, paymentMethod } = req.body;
    
    const billing = new Billing({
      memberId,
      memberName,
      gymId,
      gymName,
      plan,
      amount,
      dueDate,
      paymentMethod,
      status: 'Pending'
    });
    
    await billing.save();
    const populatedBilling = await Billing.findById(billing._id)
      .populate('memberId', 'name email phone')
      .populate('gymId', 'gymName');
    
    // Auto-send email if member email exists
    if (populatedBilling.memberId?.email) {
      try {
        const mailOptions = {
          from: process.env.EMAIL_USER,
          to: populatedBilling.memberId.email,
          subject: `New Bill Generated - ${populatedBilling.invoiceNumber}`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #8E44AD;">New Bill Generated</h2>
              <p>Dear ${populatedBilling.memberName || populatedBilling.memberId?.name},</p>
              <p>A new bill has been generated for your gym membership.</p>
              <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p><strong>Invoice Number:</strong> ${populatedBilling.invoiceNumber}</p>
                <p><strong>Gym:</strong> ${populatedBilling.gymName || populatedBilling.gymId?.gymName || 'N/A'}</p>
                <p><strong>Plan:</strong> ${populatedBilling.plan}</p>
                <p><strong>Amount:</strong> ₹${populatedBilling.amount}</p>
                <p><strong>Due Date:</strong> ${new Date(populatedBilling.dueDate).toLocaleDateString()}</p>
              </div>
              <p>Please make the payment before the due date.</p>
              <p>Thank you!</p>
            </div>
          `
        };

        if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
          await transporter.sendMail(mailOptions);
        }
      } catch (emailError) {
        console.error('Error sending email:', emailError);
        // Don't fail the request if email fails
      }
    }
    
    res.status(201).json(populatedBilling);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Generate invoice
router.post('/generate-invoice/:id', async (req, res) => {
  try {
    const bill = await Billing.findById(req.params.id)
      .populate('memberId')
      .populate('gymId');
    
    if (!bill) {
      return res.status(404).json({ message: 'Billing record not found' });
    }

    // Invoice data
    const invoiceData = {
      invoiceNumber: bill.invoiceNumber,
      date: new Date().toLocaleDateString(),
      memberName: bill.memberName || bill.memberId?.name,
      memberEmail: bill.memberId?.email,
      memberPhone: bill.memberId?.phone,
      gymName: bill.gymName || bill.gymId?.gymName,
      plan: bill.plan,
      amount: bill.amount,
      dueDate: new Date(bill.dueDate).toLocaleDateString(),
      status: bill.status,
      paymentMethod: bill.paymentMethod
    };

    res.json({ message: 'Invoice generated successfully', invoice: invoiceData });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Send payment reminder (email/SMS)
router.post('/send-reminder/:id', async (req, res) => {
  try {
    const bill = await Billing.findById(req.params.id)
      .populate('memberId')
      .populate('gymId');
    
    if (!bill) {
      return res.status(404).json({ message: 'Billing record not found' });
    }

    const memberEmail = bill.memberId?.email;
    if (!memberEmail) {
      return res.status(400).json({ message: 'Member email not found' });
    }

    // Email content
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: memberEmail,
      subject: `Payment Reminder - ${bill.invoiceNumber}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #8E44AD;">Payment Reminder</h2>
          <p>Dear ${bill.memberName || bill.memberId?.name},</p>
          <p>This is a reminder that your gym membership payment is due.</p>
          <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>Invoice Number:</strong> ${bill.invoiceNumber}</p>
            <p><strong>Gym:</strong> ${bill.gymName || bill.gymId?.gymName}</p>
            <p><strong>Plan:</strong> ${bill.plan}</p>
            <p><strong>Amount:</strong> ₹${bill.amount}</p>
            <p><strong>Due Date:</strong> ${new Date(bill.dueDate).toLocaleDateString()}</p>
          </div>
          <p>Please make the payment at your earliest convenience.</p>
          <p>Thank you!</p>
        </div>
      `
    };

    // Send email
    if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
      await transporter.sendMail(mailOptions);
      res.json({ message: 'Payment reminder sent successfully via email' });
    } else {
      // If email not configured, just return success (for development)
      console.log('Email reminder would be sent:', mailOptions);
      res.json({ message: 'Payment reminder prepared (email not configured)' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update billing status
router.put('/:id', async (req, res) => {
  try {
    const { status, paymentMethod } = req.body;
    const updateData = {};
    if (status) updateData.status = status;
    if (paymentMethod) updateData.paymentMethod = paymentMethod;
    if (status === 'Paid') updateData.paidAt = new Date();

    const bill = await Billing.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true, runValidators: true }
    )
      .populate('memberId', 'name email phone')
      .populate('gymId', 'gymName');
    
    if (!bill) {
      return res.status(404).json({ message: 'Billing record not found' });
    }
    res.json(bill);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Delete billing record
router.delete('/:id', async (req, res) => {
  try {
    const bill = await Billing.findByIdAndDelete(req.params.id);
    if (!bill) {
      return res.status(404).json({ message: 'Billing record not found' });
    }
    res.json({ message: 'Billing record deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;

