const express = require('express');
const router = express.Router();
const Settings = require('../models/Settings');

// Get settings
router.get('/', async (req, res) => {
  try {
    const settings = await Settings.getSettings();
    res.json(settings);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update settings
router.put('/', async (req, res) => {
  try {
    let settings = await Settings.findOne();
    
    if (!settings) {
      settings = new Settings(req.body);
    } else {
      Object.assign(settings, req.body);
      settings.updatedAt = new Date();
    }
    
    await settings.save();
    res.json(settings);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update membership plans
router.put('/plans', async (req, res) => {
  try {
    const { plans } = req.body;
    let settings = await Settings.findOne();
    
    if (!settings) {
      settings = new Settings({ membershipPlans: plans });
    } else {
      settings.membershipPlans = plans;
      settings.updatedAt = new Date();
    }
    
    await settings.save();
    res.json(settings);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update notification settings
router.put('/notifications', async (req, res) => {
  try {
    const { notifications } = req.body;
    let settings = await Settings.findOne();
    
    if (!settings) {
      settings = new Settings({ notifications });
    } else {
      settings.notifications = { ...settings.notifications, ...notifications };
      settings.updatedAt = new Date();
    }
    
    await settings.save();
    res.json(settings);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;

