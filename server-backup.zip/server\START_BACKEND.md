# 🚀 START BACKEND SERVER - Quick Guide

## ⚡ EASIEST WAY (Windows)

**Just double-click this file:**
```
START_BACKEND.bat
```

That's it! The server will start automatically.

---

## 📝 Manual Start (Any OS)

### Step 1: Open Terminal in Server Folder
```bash
cd Stock_market\stock_market\server
```

### Step 2: Install Dependencies (First Time Only)
```bash
npm install
```

### Step 3: Start Server
```bash
npm start
```

---

## ✅ What You Should See

When the server starts successfully, you'll see:
```
✅ MongoDB Connected Successfully
📊 Database: gym_management
✅ Server is running on port 5000
🌐 Health check: http://localhost:5000/api/health
```

---

## ⚠️ If MongoDB Error Appears

**Don't worry!** The server will still start, but some features won't work.

### Quick Fix Options:

**Option 1: Use MongoDB Atlas (Cloud - Easiest)**
1. Go to: https://www.mongodb.com/cloud/atlas
2. Sign up (free)
3. Create cluster
4. Get connection string
5. Update `.env` file with your connection string

**Option 2: Start Local MongoDB**
- **Windows:** `net start MongoDB`
- **Mac/Linux:** `mongod` or `brew services start mongodb-community`

---

## 🧪 Test if Server is Running

Open in browser: **http://localhost:5000/api/health**

**Should show:**
```json
{
  "status": "Server is running",
  "mongodb": "connected"
}
```

---

## ❌ Common Issues

### "Port 5000 already in use"
**Fix:** Kill the process or change PORT in `.env` file

### "Cannot find module"
**Fix:** Run `npm install` in the server folder

### "MongoDB Connection Error"
**Fix:** Start MongoDB or use MongoDB Atlas (see above)

---

## 🎯 Once Server is Running

1. ✅ Keep this terminal window open
2. ✅ Go back to your browser
3. ✅ Try adding a member again
4. ✅ It should work now!

---

**Need help?** Check the terminal output for error messages.



