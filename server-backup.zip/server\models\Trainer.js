const mongoose = require('mongoose');

const trainerSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    trim: true
  },
  phone: {
    type: String,
    required: true,
    trim: true
  },
  specialization: {
    type: String,
    required: true,
    enum: ['Weight Training', 'Cardio & Fitness', 'Yoga & Flexibility', 'CrossFit', 'Pilates', 'Boxing', 'Swimming']
  },
  experience: {
    type: String,
    required: true
  },
  image: {
    type: String,
    default: ''
  },
  rating: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  members: {
    type: Number,
    default: 0
  },
  status: {
    type: String,
    default: 'Active',
    enum: ['Active', 'On Leave', 'Inactive']
  },
  bio: {
    type: String,
    default: ''
  },
  certifications: [{
    type: String
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Trainer', trainerSchema);



