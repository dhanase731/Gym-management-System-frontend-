#!/bin/bash

echo "========================================"
echo " Gym Management System - Backend Server"
echo "========================================"
echo ""

echo "[1/3] Checking setup..."
npm run check
if [ $? -ne 0 ]; then
    echo ""
    echo "Setup check failed. Fixing issues..."
    npm run auto-fix
    echo ""
    read -p "Press enter to continue..."
fi

echo ""
echo "[2/3] Testing MongoDB connection..."
npm run test-connection
if [ $? -ne 0 ]; then
    echo ""
    echo "MongoDB not connected!"
    echo ""
    echo "Quick fixes:"
    echo "1. Start MongoDB: mongod"
    echo "2. Or: brew services start mongodb-community"
    echo "3. Or use MongoDB Atlas (cloud)"
    echo ""
    echo "Starting server anyway (some features may not work)..."
    echo ""
    sleep 3
fi

echo ""
echo "[3/3] Starting server..."
echo ""
npm start



