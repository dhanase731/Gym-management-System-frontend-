const express = require('express');
const router = express.Router();
const Gym = require('../models/Gym');

// Get all gyms
router.get('/', async (req, res) => {
  try {
    const gyms = await Gym.find().sort({ createdAt: -1 });
    res.json(gyms);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get single gym
router.get('/:id', async (req, res) => {
  try {
    const gym = await Gym.findById(req.params.id);
    if (!gym) {
      return res.status(404).json({ message: 'Gym not found' });
    }
    res.json(gym);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Create gym
router.post('/', async (req, res) => {
  try {
    const { gymName, phone, address, year, fee, createdBy } = req.body;
    const gym = new Gym({ gymName, phone, address, year, fee, createdBy: createdBy || 'Admin' });
    await gym.save();
    res.status(201).json(gym);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update gym
router.put('/:id', async (req, res) => {
  try {
    const { gymName, phone, address, year, fee } = req.body;
    const gym = await Gym.findByIdAndUpdate(
      req.params.id,
      { gymName, phone, address, year, fee },
      { new: true, runValidators: true }
    );
    
    if (!gym) {
      return res.status(404).json({ message: 'Gym not found' });
    }
    res.json(gym);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Delete gym
router.delete('/:id', async (req, res) => {
  try {
    const gym = await Gym.findByIdAndDelete(req.params.id);
    if (!gym) {
      return res.status(404).json({ message: 'Gym not found' });
    }
    res.json({ message: 'Gym deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;

