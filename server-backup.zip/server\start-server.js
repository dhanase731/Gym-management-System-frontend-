// Enhanced server startup with health checks
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MongoDB Connection with retry logic
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/gym_management';

let mongoConnected = false;

const connectMongoDB = async () => {
  try {
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000, // Timeout after 5s instead of 30s
    });
    mongoConnected = true;
    console.log('✅ MongoDB Connected Successfully');
    console.log('📊 Database:', mongoose.connection.name);
    return true;
  } catch (err) {
    mongoConnected = false;
    console.error('❌ MongoDB Connection Error:', err.message);
    console.error('\n🔧 Troubleshooting Steps:');
    console.error('1. For Local MongoDB:');
    console.error('   - Make sure MongoDB is installed');
    console.error('   - Start MongoDB service: mongod');
    console.error('   - Or on Windows: net start MongoDB');
    console.error('2. For MongoDB Atlas:');
    console.error('   - Check your connection string in .env file');
    console.error('   - Make sure IP is whitelisted in Atlas');
    console.error('3. Connection String:', MONGODB_URI.replace(/\/\/.*@/, '//***@'));
    return false;
  }
};

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/members', require('./routes/members'));
app.use('/api/gyms', require('./routes/gyms'));
app.use('/api/billing', require('./routes/billing'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/trainers', require('./routes/trainers'));
app.use('/api/attendance', require('./routes/attendance'));

// Health check with detailed status
app.get('/api/health', (req, res) => {
  const mongoStatus = mongoose.connection.readyState;
  const statusMap = {
    0: 'disconnected',
    1: 'connected',
    2: 'connecting',
    3: 'disconnecting'
  };
  
  res.json({ 
    status: 'Server is running',
    timestamp: new Date(),
    mongodb: statusMap[mongoStatus] || 'unknown',
    mongodbReady: mongoStatus === 1,
    port: process.env.PORT || 5000
  });
});

// Test endpoint
app.get('/api/test', async (req, res) => {
  try {
    // Test MongoDB connection
    await mongoose.connection.db.admin().ping();
    res.json({ 
      success: true, 
      message: 'All systems operational',
      mongodb: 'connected'
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'MongoDB not connected',
      error: error.message 
    });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ 
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Start server
const PORT = process.env.PORT || 5000;

const startServer = async () => {
  console.log('🚀 Starting Gym Management Server...\n');
  console.log('📁 Working directory:', __dirname);
  console.log('🔧 Node version:', process.version);
  console.log('');
  
  // Try to connect to MongoDB
  const mongoSuccess = await connectMongoDB();
  
  if (!mongoSuccess) {
    console.log('\n⚠️  Warning: MongoDB not connected. Some features may not work.');
    console.log('   Server will start anyway, but database operations will fail.');
    console.log('   💡 To fix: Start MongoDB or use MongoDB Atlas\n');
  }
  
  // Start server regardless of MongoDB status
  app.listen(PORT, (err) => {
    if (err) {
      console.error('❌ Error starting server:', err.message);
      if (err.code === 'EADDRINUSE') {
        console.error(`\n⚠️  Port ${PORT} is already in use!`);
        console.error('   Solutions:');
        console.error('   1. Kill the process using port 5000');
        console.error('   2. Change PORT in .env file');
        console.error('   3. Restart your computer\n');
      }
      process.exit(1);
    }
    
    console.log(`✅ Server is running on port ${PORT}`);
    console.log(`🌐 Health check: http://localhost:${PORT}/api/health`);
    console.log(`🧪 Test endpoint: http://localhost:${PORT}/api/test`);
    console.log('\n📝 Ready to accept requests!\n');
    console.log('💡 Keep this window open while using the application\n');
    
    if (!mongoSuccess) {
      console.log('⚠️  MongoDB Status: NOT CONNECTED');
      console.log('   Some features will not work until MongoDB is connected.\n');
    } else {
      console.log('✅ MongoDB Status: CONNECTED\n');
    }
  });
};

startServer();

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n\n🛑 Shutting down server...');
  if (mongoose.connection.readyState === 1) {
    await mongoose.connection.close();
    console.log('✅ MongoDB connection closed');
  }
  process.exit(0);
});

