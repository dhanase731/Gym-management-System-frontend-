const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
  gymName: {
    type: String,
    default: 'FitSync Gym Center'
  },
  contactEmail: {
    type: String,
    default: 'admin@fitsync.com'
  },
  phoneNumber: {
    type: String,
    default: '+91 98765 43210'
  },
  address: {
    type: String,
    default: '123 Fitness Street, Gym City, State - 560001'
  },
  membershipPlans: [{
    name: String,
    description: String,
    price: Number
  }],
  notifications: {
    email: {
      type: Boolean,
      default: true
    },
    sms: {
      type: Boolean,
      default: false
    },
    paymentReminders: {
      type: Boolean,
      default: true
    }
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Ensure only one settings document exists
settingsSchema.statics.getSettings = async function() {
  let settings = await this.findOne();
  if (!settings) {
    settings = await this.create({});
  }
  return settings;
};

module.exports = mongoose.model('Settings', settingsSchema);

